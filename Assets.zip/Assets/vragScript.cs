using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class vragScript : MonoBehaviour
{
    public float DirectionX = 1;
    public float DirectionY = 1;
    public float Speed = 2;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        Vector2 movement = new Vector2(DirectionX, DirectionY);
        transform.Translate(movement * Speed * Time.deltaTime);
    }
    private void OnCollisionEnter2D(Collision2D collision) 
    {
        if (collision.gameObject.tag == "floor")
        {
            DirectionX = DirectionX * -1;
            DirectionY = DirectionY * -1;
        }
    }

}
